using System.Collections;
using System.Collections.Generic;
using Godot;
using ai4u;

public class RadiationSource : RigidBody, IAgentResetListener
{
	[Export]
	public NodePath agentPath;
	private BasicAgent agent;
	
	[Export]
	public float probability = 0.5f;
	[Export]
	public SpatialMaterial radiationOn;
	[Export]
	public SpatialMaterial radiationOff;
	[Export]
	public NodePath meshInstancePath;
	private MeshInstance meshInstance;
	[Export]
	public bool chooseOnReset = true;
	[Export]
	public int step = 3;

	private float intensity = 0.0f;
	private System.Random rand;
	private PhysicsDirectSpaceState spaceState;
	
	public override void _Ready()
	{
			agent = GetNode(agentPath) as BasicAgent;
			this.spaceState = (this.agent.GetAvatarBody() as PhysicsBody).GetWorld().DirectSpaceState;
		
			meshInstance = GetNode(meshInstancePath) as MeshInstance;
			rand = new System.Random();
			agent.beforeTheResetEvent += OnReset;
			agent.endOfStepEvent += HandleEndOfStep;
	}

	private void HandleEndOfStep(BasicAgent agent)
	{
		if (!chooseOnReset)
		{
			if (agent.NSteps >= step && Intensity <= 0)
			{
				if (rand.NextDouble() < probability)
				{
					On();
				}
				else
				{
					Off();
				}
			}
		}
	}

	public float IntensityTo(RigidBody obj)
	{
		if (intensity == 0)
		{
			return 0.0f;
		}
		var result = this.spaceState.IntersectRay(GlobalTransform.origin, obj.GlobalTransform.origin, null, 2147483647, true, true);
		float d = (GlobalTransform.origin - obj.GlobalTransform.origin).Length();
		bool flag = false;
		if (result.Count > 0)
		{

				Vector3 tp = (Vector3)result["position"];
				float t = (obj.GlobalTransform.origin - tp).Length();					
				Spatial gobj = result["collider"] as Spatial;
				
				if (gobj == obj)
				{

					if (d > 1.0f)
					{
						return intensity/(d*d);
					}
					else
					{
						return intensity;
					}					
				}
				else
				{
					flag = true;
				}
		} else {
			flag = true;
		}
		
		if (flag)
		{
				if (d < 1f)
				{
					return intensity;
				}
				else
				{
					return 0.0f;
				}
		}
		
		return 0.0f;
	}

	public float Intensity
	{
		get
		{
			return intensity;
		}
	}

	public void On()
	{
		intensity = 1.0f;
		meshInstance.Mesh.SurfaceSetMaterial(0, radiationOn);
	}

	public void Off()
	{
		intensity = 0;
		meshInstance.Mesh.SurfaceSetMaterial(0, radiationOff);
	}

	public void OnReset(Agent agent)
	{
		if (chooseOnReset)
		{
			if (rand.NextDouble() < probability)
			{
				On();
			}
			else
			{
				Off();
			}
		}
		else
		{
			Off();
		}
	}
}
