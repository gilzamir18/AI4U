using Godot;
using System;
using ai4u;
using System.Collections.Generic;

public class RespawnTarget : RigidBody, IAgentResetListener
{
	// Declare member variables here. Examples:
	// private int a = 2;
	// private string b = "text";

	[Export]
	private NodePath positions;

	[Export]
	private NodePath agentPath;
	private BasicAgent agent;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		agent = GetNode(agentPath) as BasicAgent;
		agent.AddResetListener(this);
	}

	public void OnReset(Agent agent)
	{
				var children = GetNode(positions).GetChildren();
				int idx = (int)GD.RandRange(0, children.Count);
				
				/*var mode = rBody.Mode;
				rBody.Mode = RigidBody.ModeEnum.Kinematic;
				rBody.Position = children[idx].position;
				rBody.Mode = mode;*/

				PhysicsServer.BodySetState(
					GetRid(),
					PhysicsServer.BodyState.Transform,
					((Spatial)children[idx]).GlobalTransform
				);
				
				PhysicsServer.BodySetState(
					GetRid(),
					PhysicsServer.BodyState.AngularVelocity,
					new Vector3(0, 0, 0)
				);	
				
				PhysicsServer.BodySetState(
					GetRid(),
					PhysicsServer.BodyState.LinearVelocity,
					new Vector3(0, 0, 0)
				);
	}

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
