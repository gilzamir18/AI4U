using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using ai4u;

public class ShowSteps : MonoBehaviour
{
    public BasicAgent agent;
    public GameObject textField;


    private TMP_Text text;
    // Start is called before the first frame update
    void Start()
    {
        text = textField.GetComponent<TMP_Text>();
        text.text = "Steps: " + agent.NSteps;
    }

    // Update is called once per frame
    void Update()
    {
        text.text = "Steps: " + agent.NSteps;
    }
}
