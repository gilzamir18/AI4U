using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ai4u;

public class RadiationReward : RewardFunc
{
    public RadiationSource radiationSource;
    public float rewardScale = 0.1f;

    private BasicAgent agent;
    
    public override void OnSetup(Agent agent)
    {
        this.agent = (BasicAgent) agent;
    }

    public override void OnUpdate()
    {
        agent.AddReward(-rewardScale * radiationSource.IntensityTo(agent.gameObject));
    }

    public override void OnReset(Agent agent)
    {
    }
}

