using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ai4u;

public class RadiationSource : MonoBehaviour, IAgentResetListener
{

    public BasicAgent agent;
    public float duration = 2;
    public float probability = 0.05f;
    public Material radiationOn;
    public Material radiationOff;


    private float intensity = 0.0f;
    private float counter = 0.0f;

    void Awake()
    {
        agent.AddResetListener(this);
        agent.beginOfStepEvent += OnBeginStep;
    }

    public float IntensityTo(GameObject obj)
    {
        RaycastHit hitinfo;

        Vector3 dir = (obj.transform.position - gameObject.transform.position).normalized;

        if (Physics.Raycast(gameObject.transform.position, dir,  out hitinfo))
        {
            if (hitinfo.collider.gameObject == obj)
            {
                return intensity/(hitinfo.distance*hitinfo.distance);
            }
            else
            {
                return 0.0f;
            }
        }
        else
        {
            return 0.0f;
        }
    }

    public void OnBeginStep(BasicAgent agent)
    {
        if (intensity <= 0 && Random.Range(0.0f, 1.0f) <= probability)
        {
            intensity = 1.0f;
            GetComponent<Renderer>().material = radiationOn;
        }

        if (intensity > 0)
        {
            counter += Time.deltaTime;
            if (counter > duration)
            {
                intensity = 0;
                counter = 0;
                GetComponent<Renderer>().material = radiationOff;
            }
        }
    }

    public void OnReset(Agent agent)
    {
        intensity = 0.0f;
        counter = 0.0f;
        GetComponent<Renderer>().material = radiationOff;
    }
}
