using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ai4u;

public class RadiationSource : MonoBehaviour, IAgentResetListener
{
    public BasicAgent agent;
    public float probability = 0.5f;
    public Material radiationOn;
    public Material radiationOff;

    private float intensity = 0.0f;

    private int startEmiting = 0;

    void Awake()
    {

            SetupSource();
            agent.beginOfStepEvent += OnStep;
    }

    private void OnStep(BasicAgent a)
    {
        if (startEmiting >= 0)
        {
            if (a.NSteps >= startEmiting)
            {
                On();
                startEmiting = -1;
            }
            else
            {
                Off();
            }
        }
    }

    public void SetupSource()
    {
        agent.AddResetListener(this);
    }

    public float IntensityTo(GameObject obj)
    {
        RaycastHit hitinfo;

        Vector3 dir = (obj.transform.position - gameObject.transform.position);
        float d = dir.magnitude;
        dir = dir.normalized;

        if (Physics.Raycast(gameObject.transform.position, dir,  out hitinfo))
        {
            if (hitinfo.collider.gameObject == obj)
            {
                if (d > 1)
                {
                    return intensity/(hitinfo.distance*hitinfo.distance);
                } else
                {
                    return intensity;
                }
            }
            else
            {
                return 0.0f;
            }
        }
        else
        {
            return 0.0f;
        }
    }


    public void On()
    {
        intensity = 1.0f;
        GetComponent<Renderer>().material = radiationOn;
    }

    public void Off()
    {
        intensity = 0;
        GetComponent<Renderer>().material = radiationOff;
    }

    public void OnReset(Agent agent)
    {
        if (Random.Range(0.0f, 1.0f) < probability)
        {
            startEmiting = 1;
        }
        else
        {
            startEmiting = -1;
        }

        intensity = 0.0f;
        GetComponent<Renderer>().material = radiationOff;
    }
}
