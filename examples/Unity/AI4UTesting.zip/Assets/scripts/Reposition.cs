using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ai4u;

public class Reposition : MonoBehaviour
{
    public float minX;
    public float maxX;
    public float minZ;
    public float maxZ;
    public float y;
    public BasicAgent agent;

    // Start is called before the first frame update
    void Awake()
    {
        agent.beforeTheResetEvent += HandleBeforeTheResetEvent;
    }

    // Update is called once per frame
    public void HandleBeforeTheResetEvent(Agent agent)
    {
        //Debug.Log("Restart");
        Vector3 position;
        position.x = Random.Range(minX, maxX);
        position.y = y;
        position.z = Random.Range(minZ, maxZ);
        transform.position = position;
    }
}
