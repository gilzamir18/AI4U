using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SetSpiner : MonoBehaviour
{
    //your cicle icon
    public GameObject tick;
    //this is the fillArea of the slider
    public Transform dotParent;
    private int ticks = 2;
    
    private GameObject[] spawns = new GameObject[2];


    public void SetSpinner(float value, float min, float max) 
    {
        Rect rec = GetComponent<RectTransform>().rect;
        float width = GetComponent<Slider>().maxValue - GetComponent<Slider>().minValue;
        float dmin = ((rec.xMax - rec.xMin) * (min - GetComponent<Slider>().minValue)/width) + rec.xMin;
        float dmax = ((rec.xMax - rec.xMin) * (max - GetComponent<Slider>().minValue)/width) + rec.xMin;
        dmin /= rec.width;
        dmax /= rec.width;
        float[] pos = new float[]{dmin, dmax};
        for (int index = 0; index < ticks; index++) 
        {
            if (spawns[index] == null)
            {
                spawns[index] = Instantiate(tick, dotParent);
            }
            GameObject spawnTick = spawns[index];
            spawnTick.GetComponent<RectTransform>().anchorMin = new Vector2(pos[index]  , 0);
            spawnTick.GetComponent<RectTransform>().anchorMax = new Vector2(pos[index], 0);
            GetComponent<Slider>().value = value;
        }
    }
}
