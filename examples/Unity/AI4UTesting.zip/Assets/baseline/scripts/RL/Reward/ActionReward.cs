using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ai4u {
    public class ActionReward: RewardFunc
    {
        public virtual void RewardFrom(string actionName, BasicAgent agent) {
            
        }
    }
}
