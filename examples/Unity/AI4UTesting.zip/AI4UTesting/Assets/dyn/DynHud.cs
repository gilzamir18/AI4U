using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DynHud : MonoBehaviour
{
    public GameObject panel;
    public Slider sliderPrefab;
    public Text textPrefab;

    public Color outOfRangeColor = Color.green;

    public Color inOfRangeColor = Color.red;

    public GameObject varPanelPrefab;

    private List<Variable> variables = new List<Variable>();
    private Slider[] sliders;

    public void AddVariable(Variable v)
    {
        variables.Add(v);
    }

    public void Build()
    {
        sliders = new Slider[variables.Count];
        for (int i = 0; i < variables.Count; i++)
        {
            var varPanel = Instantiate(varPanelPrefab);
            varPanel.transform.SetParent (panel.transform);
            varPanel.transform.localScale = Vector3.one;
            varPanel.transform.localRotation = Quaternion.Euler (Vector3.zero);
            varPanel.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0, 0, 0);

            var text = Instantiate(textPrefab);
            text.transform.SetParent(varPanel.transform);
            text.GetComponent<Text>().text = variables[i].name;
            text.transform.localScale = Vector3.one;
            text.transform.localRotation = Quaternion.Euler (Vector3.zero);
            text.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0, 0, 0);    

            var slider = Instantiate(sliderPrefab);
            sliders[i] = slider.GetComponent<Slider>();
            sliders[i].minValue = variables[i].rangeMin;
            sliders[i].maxValue = variables[i].rangeMax;
            sliders[i].value = variables[i].Value;
            slider.transform.SetParent (varPanel.transform);
            slider.transform.localScale = Vector3.one;
            slider.transform.localRotation = Quaternion.Euler (Vector3.zero);
            slider.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0, 0, 0);
        }
    }

    public void UpdateVariables()
    {
        for (int i = 0; i < sliders.Length; i++)
        {
            Variable v = variables[i];
            sliders[i].GetComponent<SetSpiner>().SetSpinner(v.Value, v.minValue, v.maxValue);
            if (v.Value >= v.minValue && v.Value <= v.maxValue)
            {
                sliders[i].gameObject.transform.GetChild(0).GetComponent<Image>().color = inOfRangeColor;
            }
            else
            {
                sliders[i].gameObject.transform.GetChild(0).GetComponent<Image>().color = outOfRangeColor;
            }
        }
    }

}
