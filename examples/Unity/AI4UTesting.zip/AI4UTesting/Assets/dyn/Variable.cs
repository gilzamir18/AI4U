using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Variable
{
    public string name;
    public float rangeMin;
    public float rangeMax;
    public float minValue;
    public float maxValue;
 
    protected float mValue;

    public float Value
    {
        get
        {
            return mValue;
        }

        set
        {
            this.mValue = value;
        }
    }
}
