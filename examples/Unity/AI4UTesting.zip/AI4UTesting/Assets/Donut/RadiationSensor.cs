using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ai4u;

public class RadiationSensor : Sensor
{
    public RadiationSource radiationSource;

    private HistoryStack<float> stack;

    public override void OnSetup(Agent agent)
    {
        this.agent = (BasicAgent)agent;
        shape = new int[1]{1};
        type = SensorType.sfloatarray;
        stack = new HistoryStack<float>(shape[0]*stackedObservations);
        agent.AddResetListener(this);
    }

    public override void OnReset(Agent agent)
    {
        stack = new HistoryStack<float>(shape[0]*stackedObservations);
    }

    public override float[] GetFloatArrayValue()
    {
        float v = radiationSource.IntensityTo(this.agent.gameObject);
        stack.Push(v);
        return stack.Values;
    }
}
